Program running flow

Run the program and go to main

Call the RC4_Sender interface to enter the sender. Enter the Security Key first and then the text information. The text information is segmented into 252 bytes (if the length of the last byte is less than 252 bytes, the last byte at the end is marked with 1 in the high binary value, that is, the byte changes from 0x00 to 0x80). The message is encapsulated into a packet, and the hash value is calculated. Then the message is encrypted through RC4 and sent to the memory.

Let's go back to main

Call the RC4_Receiver interface to access the receiver.  Enter the Security Key first.  After receiving the encrypted packet data from the inside, decrypt it according to the sequence of received packets. First, compare whether the SC value of the receiver is equal to that of the packet. If not, call PRGA or IPRGA to modify and adjust the status (S, I,j) of RC4.  RC4 decryption is performed on the packet segment, and the hash value is verified.  Decrypted packet segments are output. Finally, decrypted packets are sorted together according to the sequence of received packets to form a complete transmission text.  